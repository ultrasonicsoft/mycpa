﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CheckIn
{
    internal class Constants
    {
        internal const string CPA_IMAGE_QUERY = "select CPAImage from CPA where CPAID = {0}";
        internal const string SPECIALITY_QUERY = "SELECT ID, Speciality FROM LuSpeciality";
        internal const string CPA_DETAILS_QUERY = "SELECT * FROM CPA where CPAID = {0}";
        internal const string CUSTOMER_ID_QUERY = "SELECT FirstName, LastName, Phone FROM Customer where CustomerID = {0}";
        internal const string CUSTOMER_PURPOSE_QUERY = "SELECT PurposeOfVisit ,CustomerName,ContactNumber form CPAAppointment where CPAID={0}";
    }

    internal class StoredProcedure
    {
        internal const string GetAllCPA = "[GetAllCPA]";
        internal const string GetAvailableAppointments = "[GetAvailableAppointments]";
        internal const string SignUpNewCustomer = "[SignUpNewCustomer]";
        internal const string SignUpNewCPA = "[SignUpNewCPA]";
        internal const string BookAppointment = "[BookAppointment]";
        internal const string GetUserProfile ="[GetUserProfile]"; 
        internal const string UpdateCustomer="[UpdateCustomer]";
        internal const string GetCPAProfile = "[GetCPAProfile]";
        internal const string UpdateCPA = "[UpdateCPA]";


    }
}