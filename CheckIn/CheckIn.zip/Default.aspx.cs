﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillAllSpeciality();
            }
        }

        private void FillAllSpeciality()
        {
            var result = BusinessLogic.GetAllSpecializationList();
            //ddlSpeciality.DataSource = result.Tables[0];
            //ddlSpeciality.DataTextField = result.Tables[0].Columns["Speciality"].ColumnName.ToString();
            //ddlSpeciality.DataValueField = result.Tables[0].Columns["ID"].ColumnName.ToString();
            //ddlSpeciality.DataBind();
        }

        protected void btnSearchCPA_Click(object sender, EventArgs e)
        {
            bool isCityOrZipProvided = true;

            if(string.IsNullOrEmpty(txtZipCode.Value) && string.IsNullOrEmpty(txtCity.Value))
            {

                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(),
         "err_msg",
         "alert('Please enter zip code or city to search CPA!');",
         true);
                return;
            }

            if (txtZipCode.Value.Equals("Enter Zip Code") && txtCity.Value.Equals("Enter City") )
            {
                 ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(),
          "err_msg",
          "alert('Please enter zip code or city to search CPA!');",
          true);
                return;
            }

            string zipCode = txtZipCode.Value;
            string city = txtCity.Value;

            string redirectQuery = string.Format("~/CPA/DisplayAppointments.aspx?City={0}&ZipCode={1}", city, zipCode);
            Response.Redirect(redirectQuery);
            //Response.Redirect("~/Default.aspx");
        }
    }
}