﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn.Web_Pages
{
    public partial class CPASignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                CPADetails newCPA = new CPADetails();
                //TODO: use calendar control
                newCPA.CompanyName = txtCompanyName.Text;
                newCPA.DateOfBirth = DateTime.Parse(txtMM.Text + "/" + txtDD.Text + "/" + txtYYYY.Text);
                newCPA.Email = txtEmail.Text;
                newCPA.FirstName = txtFirstName.Text;
                newCPA.LastName = txtLastName.Text;
                newCPA.Password = txtPassword.Text;
                newCPA.PhoneNumber = txtPhoneNumber.Text;
                newCPA.Gender = rbtnMale.Checked ? "M" : "F";

                newCPA.Address1 = txtOfficeAddress1.Text;
                newCPA.Address2 = txtOfficeAddress2.Text;
                newCPA.ZipCode = txtZipCode.Text;
                newCPA.City = txtPractingCity.Text;
                newCPA.State = txtPractingState.Text;
                //TODO: check how to handle speciality
                newCPA.Speciality = txtSpeciality.Text;

                int len = ImageUpload.PostedFile.ContentLength;
                byte[] pic = new byte[len];
                ImageUpload.PostedFile.InputStream.Read(pic, 0, len);
                newCPA.Image = pic;

                bool result = BusinessLogic.CreateNewCPA(newCPA);
                if (result)
                {

                    //TODO: set login user name. FormsAuthentication.SetCookies
                    Session["roleID"] = 2;

                    string user;

                    if ((user = BusinessLogic.GetLoggedInCPAName(txtEmail.Text, txtPassword.Text)) != null)
                    {
                        Session["userName"] = user;
                    }
                    int userID = BusinessLogic.GetNewUserID();
                    Session["userID"] = userID;
                    Response.Redirect("~/CPA/ManageAppointment.aspx");
                }
            }
        }

        //protected void checkCheckBox1(object source, ServerValidateEventArgs args)
        //{
        //    if (cbTermCondition1.Checked == true)
        //    {
        //        args.IsValid = true;
        //    }
        //    else
        //    {
        //        args.IsValid = false;
        //    }
        //}

        
    }
}