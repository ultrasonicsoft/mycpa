﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn.Web_Pages
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                CustomerDetails newCustomer = new CustomerDetails();
                //TODO: use calendar control
                newCustomer.DateOfBirth = DateTime.Parse(txtMM.Text + "/" + txtDD.Text + "/" + txtYYYY.Text);
                newCustomer.Email = txtEmail.Text;
                newCustomer.FirstName = txtFirstName.Text;
                newCustomer.LastName = txtLastName.Text;
                newCustomer.Password = txtPassword.Text;
                newCustomer.PhoneNumber = txtPhoneNumber.Text;
                newCustomer.Gender = rbtnMale.Checked ? "M" : "F";
                bool result = BusinessLogic.CreateNewCustomer(newCustomer);
                if (result)
                {
                    //TODO: set login user name. FormsAuthentication.SetCookies
                    string user;

                    Session["roleID"] = 1;

                    int userID = BusinessLogic.GetNewUserID();
                    Session["userID"] = userID;
                    if ((user = BusinessLogic.GetLoggedInUserName(txtEmail.Text, txtPassword.Text)) != null)
                    {
                        Session["userName"] = user;
                        Response.Redirect("~/CPA/DisplayAppointments.aspx");
                    }

                }
            }

        }
        protected void checkCheckBox(object source, ServerValidateEventArgs args)
        {
            if (cbTermCondition.Checked == true)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;
            }

        }
    }
}