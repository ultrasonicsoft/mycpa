﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn.CPA
{
    public partial class CPAProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                RefreshUserDetail();
            }
        }
        private void RefreshUserDetail()
        {
            var result = BusinessLogic.GetCPAProfileDetail(int.Parse(Session["userID"].ToString()));
           //var result = BusinessLogic.GetuserProfileDetail(int.Parse("3"));
            if (result == null || result.Tables[0].Rows.Count == 0)
                return;
            txtCompanyName.Text = result.Tables[0].Rows[0]["CompanyName"].ToString();
            txtOfficeAddress1.Text = result.Tables[0].Rows[0]["Address1"].ToString();
            txtOfficeAddress2.Text = result.Tables[0].Rows[0]["Address2"].ToString();
            txtPractingCity.Text = result.Tables[0].Rows[0]["City"].ToString();
            txtPractingState.Text = result.Tables[0].Rows[0]["State"].ToString();
            txtZipCode.Text = result.Tables[0].Rows[0]["ZipCode"].ToString();
            txtEmail.Text = result.Tables[0].Rows[0]["Email"].ToString();
            txtPassword.Text = result.Tables[0].Rows[0]["Password"].ToString();
            txtFirstName.Text = result.Tables[0].Rows[0]["FirstName"].ToString();
            txtLastName.Text = result.Tables[0].Rows[0]["LastName"].ToString();
            //string str = string.Format("~/Doc/ImageCSharp.aspx?CPAID={0}", Session["userID"]);
            Image1.ImageUrl = "Handler.ashx?QueryCPAID=" + Session["userID"];
            txtMM.Text = result.Tables[0].Rows[0]["Month"].ToString();
            txtDD.Text = result.Tables[0].Rows[0]["Date"].ToString();
            txtYYYY.Text = result.Tables[0].Rows[0]["Year"].ToString();
            if (result.Tables[0].Rows[0]["Gender"].ToString() == "M")
            {
                rbtnMale.Checked = true;

            }
            else
            {
                rbtnFemale.Checked = true;
            }

            txtPhoneNumber.Text = result.Tables[0].Rows[0]["Phone"].ToString();
            txtSpeciality.Text = result.Tables[0].Rows[0]["SpecialityID"].ToString();

          
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            CPADetails CPAUser =new CPADetails();
            //TODO: use calendar control
            CPAUser.UserID = Session["userID"].ToString();
            //customer.UserID = "3";
            CPAUser.CompanyName=txtCompanyName.Text;
            CPAUser.Address1=txtOfficeAddress1.Text;
            CPAUser.Address2=txtOfficeAddress2.Text;
            CPAUser.City=txtPractingCity.Text;
            CPAUser.State=txtPractingState.Text;
            CPAUser.ZipCode=txtZipCode.Text;
            CPAUser.PhoneNumber = txtPassword.Text;
            CPAUser.FirstName = txtFirstName.Text;
            CPAUser.LastName = txtLastName.Text;
          //  CPAUser.Image=
           // string str = txtDD.Text + "/" + txtMM.Text + "/" + txtYYYY.Text;
            CPAUser.DateOfBirth = DateTime.Parse(txtMM.Text + "/" + txtDD.Text + "/" + txtYYYY.Text);
            CPAUser.Gender = rbtnMale.Checked ? "M" : "F";
            CPAUser.Speciality = txtSpeciality.Text;
            CPAUser.Email = txtEmail.Text;
            CPAUser.Password = txtPassword.Text;


            int len = ImageUpload.PostedFile.ContentLength;
            byte[] pic = new byte[len];
            ImageUpload.PostedFile.InputStream.Read(pic, 0, len);
            CPAUser.Image = pic;
            
            //CPAUser.DateOfBirth = DateTime.Parse(txtDD.Text + "/" + txtMM.Text + "/" + txtYYYY.Text);
          

             bool result=BusinessLogic.UpdateCPADetails(CPAUser);

             if (result)
             {
                 Session["userName"] = txtFirstName.Text;
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE='JavaScript'>alert('Save Sucessful')</SCRIPT>");
             }
           
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtCompanyName.Text = "";
            txtOfficeAddress1.Text = "";
            txtOfficeAddress2.Text = "";
            txtPractingCity.Text = "";
            txtPractingState.Text = "";
            txtZipCode.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtMM.Text = "";
            txtDD.Text = "";
            txtYYYY.Text = "";
            rbtnMale.Checked = false;
            rbtnFemale.Checked = false; 
            txtPhoneNumber.Text = "";
            txtSpeciality.Text = "";
        }
        }
    }
