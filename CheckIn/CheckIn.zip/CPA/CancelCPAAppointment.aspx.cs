﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn.CPA
{
    public partial class CancelCPAAppointment : System.Web.UI.Page
    {
       
            
        #region Private Members

        private string cpid = string.Empty;
        private string schedule = string.Empty;
        private string id = string.Empty;
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack && Request.QueryString.Count > 0)
            { 
                RefreshAppointment();
            }
        }
        private void RefreshAppointment()
        {
         int result = BusinessLogic.CancelAppointment(Request.QueryString["ID"]);
            if (result != 0)
            {  
                Response.Redirect(String.Format("~/CPA/ViewScheduledAppointments.aspx?UserID={0}" , Session["userID"]));
            }
        }
       
    }
}