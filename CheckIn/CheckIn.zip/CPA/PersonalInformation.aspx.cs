﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn.CPA
{
    public partial class PersonalInformation : System.Web.UI.Page
    {
        #region Private Members

        private string cpid = string.Empty;
        private string scheduledTime = string.Empty;
        private string scheduledDate = string.Empty;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && Request.QueryString.Count > 0)
            {
                cpid = Request.QueryString["CPAID"];
                imgCPA.ImageUrl = "Handler.ashx?QueryCPAID=" + cpid;
                FillAllSpeciality();
                RefreshPageData();
            }
        }
        private void FillAllSpeciality()
        {
            var result = BusinessLogic.GetAllSpecializationList();
            ddlSpeciality.DataSource = result.Tables[0];
            ddlSpeciality.DataTextField = result.Tables[0].Columns["Speciality"].ColumnName.ToString();
            ddlSpeciality.DataValueField = result.Tables[0].Columns["ID"].ColumnName.ToString();
            ddlSpeciality.DataBind();
        }
        private void RefreshPageData()
        {
            var result = BusinessLogic.GetCPADetails(int.Parse(cpid));
            if (result == null || result.Tables[0].Rows.Count == 0)
                return;

            lnkCPADetail.Text = result.Tables[0].Rows[0]["CompanyName"].ToString();
            lnkCPADetail.NavigateUrl = "CPADetails.aspx?CPAID=" + cpid;
            lblName.Text = result.Tables[0].Rows[0]["CompanyName"].ToString();
            lblAddress1.Text = result.Tables[0].Rows[0]["Address1"].ToString();
            lblAddress2.Text = result.Tables[0].Rows[0]["Address2"].ToString();
            lblState.Text = result.Tables[0].Rows[0]["State"].ToString();
            lblZipCode.Text = result.Tables[0].Rows[0]["ZipCode"].ToString();

            lblScheduleDate.Text = Request.QueryString["Schedule"];
            lblPurposeOfVisit.Text = Request.QueryString["Purpose"];

            RefreshCustomerDetails();
        }

        private void RefreshCustomerDetails()
        {
            var result = BusinessLogic.GetCustomerDetails(Request.QueryString["UserID"]);
            if (result == null || result.Tables[0].Rows.Count == 0)
                return;

            lblCustomerName.Text = result.Tables[0].Rows[0]["LastName"].ToString() + ", " + result.Tables[0].Rows[0]["FirstName"].ToString();
            lblPhoneNumber.Text = result.Tables[0].Rows[0]["Phone"].ToString();
        }

        protected void btnEditContact_Click(object sender, EventArgs e)
        {
            var result = BusinessLogic.GetCustomerDetails(Session["userID"].ToString());
            if (result == null || result.Tables[0].Rows.Count == 0)
                return;
            txtFirstName.Text = result.Tables[0].Rows[0]["FirstName"].ToString();
            txtLastName.Text = result.Tables[0].Rows[0]["LastName"].ToString();
            txtPhoneNumber.Text = result.Tables[0].Rows[0]["Phone"].ToString();
            pnlEditCustomerDetails.Visible = true;
            pnlCustomerDetails.Visible = false;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            pnlEditCustomerDetails.Visible = false;
            pnlCustomerDetails.Visible = true;
        }

        protected void btnSaveContactInformation_Click(object sender, EventArgs e)
        {
            pnlEditCustomerDetails.Visible = false;
            pnlCustomerDetails.Visible = true;
 
            string updateQuery = string.Format("UPDATE Customer SET FirstName='{0}', LastName='{1}',Phone='{2}' WHERE CustomerID={3}", txtFirstName.Text, txtLastName.Text, txtPhoneNumber.Text, Request.QueryString["UserID"]);
            DBHelper.ExecuteNonQuery(updateQuery);

            RefreshCustomerDetails();
        }

        protected void btnBookAppointment_Click(object sender, EventArgs e)
        {
            string scheduleDateID =  Request.QueryString["ID"];
            bool result = BusinessLogic.BookNewAppointment(Request.QueryString["CPAID"], Request.QueryString["UserID"], lblPurposeOfVisit.Text, scheduleDateID);
            if (result)
            {
                string redirectURL = string.Format("~/CPA/FinishBookingApp.aspx?CPAID={0}&Schedule={1}&Purpose={2}&ID={3}&UserID={4}", Request.QueryString["CPAID"], lblScheduleDate.Text, lblPurposeOfVisit.Text, Request.QueryString["ID"], Request.QueryString["UserID"]);
                Response.Redirect(redirectURL);
            }
        }

        protected void btnRefineSearch_Click(object sender, EventArgs e)
        {

            string specialityID = ddlSpeciality.SelectedItem.Value;
            string zipCode = string.IsNullOrEmpty(txtZipCode.Text) || txtZipCode.Text.Equals(@"Enter Zip Code\City") ? string.Empty : txtZipCode.Text;

            string redirectQuery = string.Format("~/CPA/DisplayAppointments.aspx?SpecialityID={0}&ZipCode={1}", specialityID, zipCode);
            Response.Redirect(redirectQuery);
        }
    }
}