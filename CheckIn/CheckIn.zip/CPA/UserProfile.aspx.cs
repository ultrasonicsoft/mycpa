﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheckIn.CPA
{
    public partial class UserProfile : System.Web.UI.Page
    {
        #region

        private string specialityID = string.Empty;
        private string zipCode = string.Empty;

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack )
            {

                if (Request.QueryString.Count == 1)
                {
                    specialityID = Request.QueryString["SpecialityID"];

                }

                if (Request.QueryString.Count == 2)
                {
                    specialityID = Request.QueryString["SpecialityID"];
                    zipCode = Request.QueryString["ZipCode"];
                }

                 FillAllSpeciality();
                 RefreshUserDetail();
            }
        }

        private void FillAllSpeciality()
        {
            var result = BusinessLogic.GetAllSpecializationList();
            ddlSpeciality.DataSource = result.Tables[0];
            ddlSpeciality.DataTextField = result.Tables[0].Columns["Speciality"].ColumnName.ToString();
            ddlSpeciality.DataValueField = result.Tables[0].Columns["ID"].ColumnName.ToString();
            ddlSpeciality.DataBind();
        }

        private void RefreshUserDetail()
        {
           var result = BusinessLogic.GetuserProfileDetail(int.Parse(Session["userID"].ToString()));
           //var result = BusinessLogic.GetuserProfileDetail(int.Parse("3"));
            if (result == null || result.Tables[0].Rows.Count == 0)
                return;
            txtEmail.Text = result.Tables[0].Rows[0]["Email"].ToString();
            txtPassword.Text = result.Tables[0].Rows[0]["Password"].ToString();
            txtFirstName.Text = result.Tables[0].Rows[0]["FirstName"].ToString();
            txtLastName.Text = result.Tables[0].Rows[0]["LastName"].ToString();
            txtMM.Text = result.Tables[0].Rows[0]["Month"].ToString();
            txtDD.Text = result.Tables[0].Rows[0]["Date"].ToString();
            txtYYYY.Text = result.Tables[0].Rows[0]["Year"].ToString();
            if (result.Tables[0].Rows[0]["Gender"].ToString() == "M")
            {
                rbtnMale.Checked = true;

            }
            else
            {
                rbtnFemale.Checked = true;
            }

            txtPhoneNumber.Text = result.Tables[0].Rows[0]["Phone"].ToString();
           // txtPassword.Text=re
          
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            CustomerDetails customer = new CustomerDetails();
            //TODO: use calendar control
            customer.UserID = Session["userID"].ToString();
            //customer.UserID = "3";
            customer.Email = txtEmail.Text;
            customer.Password = txtPassword.Text;
            customer.FirstName = txtFirstName.Text;
            customer.LastName = txtLastName.Text;

            customer.DateOfBirth = DateTime.Parse(txtMM.Text + "/" + txtDD.Text + "/" + txtYYYY.Text);
            customer.Gender = rbtnMale.Checked ? "M" : "F";
            customer.PhoneNumber = txtPhoneNumber.Text;

             bool result=BusinessLogic.UpdateCustomerDetails(customer);

             if (result)
             {
                 Session["userName"] = txtFirstName.Text;
                System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE='JavaScript'>alert('Save Sucessful')</SCRIPT>");
             }
           
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtFirstName.Text ="";
            txtLastName.Text = "";
            txtMM.Text = "";
            txtDD.Text ="";
            txtYYYY.Text ="";
            rbtnMale.Checked = false;
            rbtnFemale.Checked = false;
            txtPhoneNumber.Text = "";
        }

        #region Refine Search

        protected void btnRefineSearch_Click(object sender, EventArgs e)
        {
            GetCurrentSearchFilter();

            RefreshUserDetail();
        }

        private void GetCurrentSearchFilter()
        {
            string specialityID = ddlSpeciality.SelectedItem.Value;
            string zipCode = string.IsNullOrEmpty(txtZipCode.Text) || txtZipCode.Text.Equals(@"Enter Zip Code\City") ? string.Empty : txtZipCode.Text;

            string redirectQuery = string.Format("~/CPA/DisplayAppointments.aspx?SpecialityID={0}&ZipCode={1}", specialityID, zipCode);
            Response.Redirect(redirectQuery);
        }

        #endregion
    }
}