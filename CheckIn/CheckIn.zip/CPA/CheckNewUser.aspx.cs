﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

namespace CheckIn.CPA
{
    public partial class CheckNewUser : System.Web.UI.Page
    {
        #region Private Members

        private string cpid = string.Empty;
        private string schedule = string.Empty;
        private string scheduledTime = string.Empty;
        private string scheduledDate = string.Empty;
        private string purpose = string.Empty;
        private string id = string.Empty;
        private int role;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && Request.QueryString.Count > 0)
            {
                cpid = Request.QueryString["CPAID"];
                schedule = Request.QueryString["Schedule"];
                scheduledTime = Request.QueryString["ScheduledTime"];
                scheduledDate = Request.QueryString["ScheduledDate"];
                purpose = Request.QueryString["Purpose"];
                id = Request.QueryString["ID"];
                imgCPA.ImageUrl = "Handler.ashx?QueryCPAID=" + cpid;
                FillAllSpeciality();
                RefreshBookingAppointments();
            }

            if (Session["userName"] != null && int.Parse(Session["roleID"].ToString())==1)
            {
                pnlLoggedIn.Visible = true;
                pnlNotLoggedIn.Visible = false;
                lblUserName.Text = "LoggedIn User " + Session["userName"].ToString();

            }
            else
            {
                pnlLoggedIn.Visible = false;
                pnlNotLoggedIn.Visible = true;
            }
        }
        private void FillAllSpeciality()
        {
            var result = BusinessLogic.GetAllSpecializationList();
            ddlSpeciality.DataSource = result.Tables[0];
            ddlSpeciality.DataTextField = result.Tables[0].Columns["Speciality"].ColumnName.ToString();
            ddlSpeciality.DataValueField = result.Tables[0].Columns["ID"].ColumnName.ToString();
            ddlSpeciality.DataBind();
        }
        private void RefreshBookingAppointments()
        {
            var result = BusinessLogic.GetCPADetails(int.Parse(cpid));
            if (result == null || result.Tables[0].Rows.Count == 0)
                return;

            lnkCPADetail.Text = result.Tables[0].Rows[0]["CompanyName"].ToString();
            lnkCPADetail.NavigateUrl = "CPADetails.aspx?CPAID=" + cpid;
            lblName.Text = result.Tables[0].Rows[0]["CompanyName"].ToString();
            lblAddress1.Text = result.Tables[0].Rows[0]["Address1"].ToString();
            lblAddress2.Text = result.Tables[0].Rows[0]["Address2"].ToString();
            lblState.Text = result.Tables[0].Rows[0]["State"].ToString();
            lblZipCode.Text = result.Tables[0].Rows[0]["ZipCode"].ToString();

            lblScheduleDate.Text = Request.QueryString["Schedule"];
            lblPurposeOfVisit.Text = Request.QueryString["Purpose"];
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {

        }

        protected void btnNewUser_Click(object sender, EventArgs e)
        {
            pnlNewUser.Visible = true;
            pnlRegisteredUser.Visible = false;
            btnBack.Visible = false;
        }

        protected void btnRegisteredUser_Click(object sender, EventArgs e)
        {
            pnlNewUser.Visible = false;
            pnlRegisteredUser.Visible = true;
            btnBack.Visible = false;
        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            bool result;
            if (result = BusinessLogic.IsLoginSuccessful(txtLoginEmail.Text, txtLoginPassword.Text))
            {
                if ((role = BusinessLogic.GetRoleID(txtLoginEmail.Text, txtLoginPassword.Text)) > 0)
                {
                    string user;
                    if ((user = BusinessLogic.GetLoggedInUserName(txtLoginEmail.Text, txtLoginPassword.Text)) != null)
                    {
                        Session["userName"] = user;
                        Session["roleID"] = role;
                    }

                    int userID = BusinessLogic.GetUserID(txtLoginEmail.Text, txtLoginPassword.Text);
                    Session["userID"] = userID;
                    string redirectURL = string.Format("~/CPA/PersonalInformation.aspx?CPAID={0}&Schedule={1}&Purpose={2}&UserID={3}&ID={4}", Request.QueryString["CPAID"], lblScheduleDate.Text,
                                    lblPurposeOfVisit.Text, userID, Request.QueryString["ID"]);
                    //TODO: set login user name. FormsAuthentication.SetCookies
                    Response.Redirect(redirectURL);
                }
            }
            else
            {
                loginValidation.IsValid = false;
            }
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            if (!IsTermsAccepted())
                return;

            CustomerDetails newCustomer = new CustomerDetails();
            //TODO: use calendar control
            newCustomer.DateOfBirth = DateTime.ParseExact(txtDD.Text + "/" + txtMM.Text + "/" + txtYYYY.Text, "M/d/yyyy", CultureInfo.InvariantCulture);
            newCustomer.Email = txtEmail.Text;
            newCustomer.FirstName = txtFirstName.Text;
            newCustomer.LastName = txtLastName.Text;
            newCustomer.Password = txtPassword.Text;
            newCustomer.PhoneNumber = txtPhoneNumber.Text;
            newCustomer.Gender = rbtnMale.Checked ? "M" : "F";
            bool result = BusinessLogic.CreateNewCustomer(newCustomer);
           
            if (result)
            {
              
                string user;
                Session["roleID"] = 1;
                if ((user = BusinessLogic.GetLoggedInUserName(txtEmail.Text, txtPassword.Text)) != null)
                {
                    Session["userName"] = user;
                }
                int userID = BusinessLogic.GetNewUserID();
                Session["userID"] = userID;
                string redirectURL = string.Format("~/CPA/PersonalInformation.aspx?CPAID={0}&Schedule={1}&Purpose={2}&UserID={3}&ID={4}", Request.QueryString["CPAID"], lblScheduleDate.Text,
                                lblPurposeOfVisit.Text, userID, Request.QueryString["ID"]);
                //TODO: set login user name. FormsAuthentication.SetCookies
                Response.Redirect(redirectURL);
            }
        }

        private bool IsTermsAccepted()
        {
            valTermsConditions.IsValid = cbAcceptTerms.Checked;
            return valTermsConditions.IsValid;
        }

        protected void btnContinue_Click(object sender, EventArgs e)
        {
            int userID = int.Parse(Session["userID"].ToString());


            string redirectURL = string.Format("~/CPA/PersonalInformation.aspx?CPAID={0}&Schedule={1}&Purpose={2}&UserID={3}&ID={4}", Request.QueryString["CPAID"], lblScheduleDate.Text,
                            lblPurposeOfVisit.Text, userID, Request.QueryString["ID"]);
            Response.Redirect(redirectURL);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            string redirectURL = string.Format("~/CPA/BookAppointment.aspx?CPAID={0}&Schedule={1}&ID={2}", Request.QueryString["CPAID"], lblScheduleDate.Text, Request.QueryString["ID"]);
            Response.Redirect(redirectURL);
        }

        protected void btnRefineSearch_Click(object sender, EventArgs e)
        {

            string specialityID = ddlSpeciality.SelectedItem.Value;
            string zipCode = string.IsNullOrEmpty(txtZipCode.Text) || txtZipCode.Text.Equals(@"Enter Zip Code\City") ? string.Empty : txtZipCode.Text;

            string redirectQuery = string.Format("~/CPA/DisplayAppointments.aspx?SpecialityID={0}&ZipCode={1}", specialityID, zipCode);
            Response.Redirect(redirectQuery);
            //Response.Redirect("~/Default.aspx");
        }
    }    
    
}